import mysql from 'mysql2/promise';
import 'dotenv/config';

async function testConnection() {
    console.log("Connecting to:", {
        host: process.env.DB_HOST,
        port: process.env.DB_PORT || 3306,
        user: process.env.DB_USER,
        database: process.env.DB_NAME,
    });
    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            port: Number(process.env.DB_PORT || 3306),
            user: process.env.DB_USER,
            password: process.env.DB_PASS,
            database: process.env.DB_NAME,
            connectTimeout: 5000
        });
        console.log("SUCCESSFULLY CONNECTED!");
        const [rows] = await connection.query('SELECT 1 + 1 AS solution');
        console.log("Query test result:", rows);
        await connection.end();
    } catch (err) {
        console.error("CONNECTION FAILED:", err);
    }
}

testConnection();
