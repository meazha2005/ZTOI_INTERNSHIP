import mysql from 'mysql2/promise';
import 'dotenv/config';

async function testWithSsl(sslEnabled) {
    const sslConfig = sslEnabled ? { rejectUnauthorized: false } : undefined;
    console.log(`Testing with sslEnabled = ${sslEnabled}...`);
    try {
        const connection = await mysql.createConnection({
            host: process.env.DB_HOST,
            port: Number(process.env.DB_PORT || 3306),
            user: process.env.DB_USER,
            password: process.env.DB_PASS,
            database: process.env.DB_NAME,
            ssl: sslConfig,
            connectTimeout: 5000
        });
        console.log(`-> SUCCESS with sslEnabled = ${sslEnabled}!`);
        await connection.end();
        return true;
    } catch (err) {
        console.log(`-> FAILED with sslEnabled = ${sslEnabled}:`, err.message);
        return false;
    }
}

async function run() {
    const sslOk = await testWithSsl(true);
    const noSslOk = await testWithSsl(false);
    console.log("Summary:", { sslOk, noSslOk });
}

run();
