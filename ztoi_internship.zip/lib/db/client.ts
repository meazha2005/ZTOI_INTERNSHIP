import mysql from 'mysql2/promise';
import 'dotenv/config';

const host = process.env.DB_HOST;
const port = process.env.DB_PORT ? parseInt(process.env.DB_PORT, 10) : 3306;
const user = process.env.DB_USER;
const password = process.env.DB_PASS;
const database = process.env.DB_NAME;

// Serverless platforms auto-scale horizontally. Keep pool size low to prevent connection exhaustion.
const connectionLimit = process.env.DB_CONNECTION_LIMIT 
  ? parseInt(process.env.DB_CONNECTION_LIMIT, 10) 
  : 3;

// Cloud databases (Aiven, TiDB, PlanetScale, Hostinger, AWS RDS, DigitalOcean, etc.) require SSL over the internet.
// If DB_SSL is true, or if it is a remote database (not localhost) and DB_SSL is not explicitly 'false', we enable SSL.
const isLocalhost = !host || [
    'localhost',
    '127.0.0.1',
    '::1'
].includes(host.trim().toLowerCase());

const sslEnabled = process.env.DB_SSL === 'true';

let sslConfig = undefined;
if (sslEnabled) {
    sslConfig = {
        rejectUnauthorized: process.env.DB_SSL_REJECT_UNAUTHORIZED === 'true',
        ca: process.env.DB_SSL_CA || undefined
    };
}

// Log host/port details (safely masking password) ONLY during development.
if (process.env.NODE_ENV !== 'production') {
    console.log(`[Database Client] Initializing connection pool: host=${host}, port=${port}, user=${user}, database=${database}, ssl=${sslEnabled}, connectionLimit=${connectionLimit}`);
}

// Singleton pattern to prevent multiple pool instances in Serverless/Development
const globalForDb = globalThis as unknown as { mysqlPool: mysql.Pool };

export const pool = globalForDb.mysqlPool || mysql.createPool({
    host,
    port,
    user,
    password,
    database,
    waitForConnections: true,
    connectionLimit,
    queueLimit: 0,
    ssl: sslConfig,
    enableKeepAlive: true,
    keepAliveInitialDelay: 10000,
    connectTimeout: 10000
});

if (process.env.NODE_ENV !== 'production') {
    globalForDb.mysqlPool = pool;
}

export const closeConnection = async () => {
    // In serverless, we must avoid closing the global pool between requests.
    // We keep this function as a no-op / safe wrapper for legacy code compatibility.
};
